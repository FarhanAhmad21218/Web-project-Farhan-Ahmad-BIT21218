let btn = document.querySelector("button");
let thirdElement = document.querySelector("ul");
btn.addEventListener("click", () => {
  thirdElement.lastElementChild.innerText = "Changed";
});
