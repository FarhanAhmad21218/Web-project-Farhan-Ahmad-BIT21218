const drums = document.querySelectorAll(".drum");

drums.forEach((drum) => {
  drum.addEventListener("click", function () {
    const buttonText = this.textContent;
    playSound(buttonText);
    addAnimation(this);
  });
});
document.addEventListener("keydown", function (event) {
  const keyPressed = event.key;
  playSound(keyPressed);
  const button = findDrumByKey(keyPressed);
  if (button) {
    addAnimation(button);
  }
});
function addAnimation(drum) {
  drum.classList.add("pressed");
  setTimeout(() => {
    drum.classList.remove("pressed");
  }, 100);
}

function playSound(key) {
  const audio = new Audio(`sounds/${key}.mp3`);
  audio.play();
}
function findDrumByKey(key) {
  return Array.from(drums).find((drum) => drum.textContent === key);
}
